# Mangia Mangia
This app helps restaurants optimize menus, reduce waste, and delight guests with Nonna as your kitchen assistant.
