# Streamlit app with Nonna animations
print('App with Nonna loaded')
